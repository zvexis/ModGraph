You can uncomment "//#define USE_CV" to draw you graphs, however, you'll need OpenCV library for that.

All algorithms can be found in file dpTree.cpp, although, it is messy a bit, I am going to clear it later